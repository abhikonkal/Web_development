
var gamepattern=[]
var buttonColors=["red", "blue", "green", "yellow"];
var userClickedPattern=[]


function nextsequence()
{
    var randomNumber=Math.round(Math.random(0,1)*3);

    
    var randomchosenColor=buttonColors[randomNumber];

    gamepattern.push(randomchosenColor);

    $("."+randomchosenColor).fadeOut(100).fadeIn(100).fadeOut(100).fadeIn(100);
    makesound(randomchosenColor);
}



function makesound(color){
    console.log(color)
    var audio=new Audio("sounds/"+color+".mp3");
    audio.play();
}



nextsequence();


